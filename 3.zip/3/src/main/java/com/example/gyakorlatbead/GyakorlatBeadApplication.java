package com.example.gyakorlatbead;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GyakorlatBeadApplication {

    public static void main(String[] args) {
        SpringApplication.run(GyakorlatBeadApplication.class, args);
    }

}
