package com.example.gyakorlatbead;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GyakorlatBeadApplicationTests {

    @Test
    void contextLoads() {
    }

}
