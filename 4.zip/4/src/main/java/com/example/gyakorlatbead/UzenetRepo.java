package com.example.gyakorlatbead;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UzenetRepo extends JpaRepository<Uzenet, Long>{
}
