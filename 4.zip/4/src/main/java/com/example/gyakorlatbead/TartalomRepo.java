package com.example.gyakorlatbead;
import org.springframework.data.repository.CrudRepository;

public interface TartalomRepo extends CrudRepository<Tartalom, Integer>{
}
