package com.example.gyakorlatbead;
import org.springframework.data.repository.CrudRepository;

public interface ArRepo  extends CrudRepository<Ar, Integer>{
}
